 document.getElementById('crear').addEventListener('click', function() {
    window.location.href = 'src/crearsala.html';
  });
  
  document.getElementById('lista').addEventListener('click', function() {
    window.location.href = 'src/listadesalas.html';
  });
  
  document.getElementById('unirse').addEventListener('click', function() {
    window.location.href = 'src/unirse.html';
  });
  